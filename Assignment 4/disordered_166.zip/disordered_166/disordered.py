def disordered(A,n):
    ctr=0
    for i in range(n):
        for j in range(i+1,n):
            if A[i]>A[j]:
                ctr+=1
    return ctr



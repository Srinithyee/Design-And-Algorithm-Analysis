def fast_disorder(A,n):
    if(n<=1):
        return 1
    mix=A.index(max(A))
    A.remove(A[mix])
    n-=1
    return (n-mix)+fast_OutOrder(A[:n//2],n//2)+fast_OutOrder(A[n//2:],n-(n//2))
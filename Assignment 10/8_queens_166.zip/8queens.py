class Queens:
	
	def __init__(self, n):
		self.board = [[0 for i in range(n)] for j in range(n)]
		self.n = n

	def printBoard(self):
		for i in range(self.n):
			for j in range(self.n):
				print(self.board[i][j], end = "  ")
			print("\n")

	def Safe(self, row, col):
		
		for i in range(col):
			if(self.board[row][i] == 1):
				return False
		
		i, j = row, col
		
		for i, j in zip(range(row, -1, -1), range(col, -1, -1)):
			if(self.board[i][j] == 1):
				return False
			
		i, j = row, col #check left side of lower diagonal
		
		for i, j in zip(range(row, self.n, -1), range(col, -1, -1)):
			if(self.board[i][j] == 1):
				return False

		return True # hence safe
	
	
	def solveBoard(self, col):
		if(col >= self.n):	#base case, all columns are checked.
			print("FINAL STATUS (1 REPRESENTS POSITION OF QUEEN): \n")
			self.printBoard()
			return True	#if this statement is removed, all solutions will be printed

		for i in range(self.n):
			if(self.isSafe(i, col) == True):	#if the board is in a safe state, place Queen in the ith row
				self.board[i][col] = 1
				if(self.solveBoard(col+1) == True):	#check recursively if it is solvable with current state
										
					return True	#if solvable, return True
				else:					#if the board isn't in a safe state, do not place Queen in that row. 
					self.board[i][col] = 0
		
		return False	#if the configuration is unsolvable, return False, so that other configurations are tried.


if __name__ == "__main__":

	queens_8 = Queens(8)
	print("\n\AT THE START BOARD LOOKS LIKE: \n")
	queens_8.printBoard()

	print("\n\t\tPLACING QUEENS....\n")
	final = queens_8.solveBoard(0)

	if(final == False):
		print("\nThe board was not solvable.")



"""
OUTPUT::

	AT THE START BOARD LOOKS LIKE

0  0  0  0  0  0  0  0  

0  0  0  0  0  0  0  0  

0  0  0  0  0  0  0  0  

0  0  0  0  0  0  0  0  

0  0  0  0  0  0  0  0  

0  0  0  0  0  0  0  0  

0  0  0  0  0  0  0  0  

0  0  0  0  0  0  0  0  


	PLACING QUEENS....
 

	FINAL STATUS (1 REPRESENTS POSITION OF QUEEN):
	
1  0  0  0  0  0  0  0  

0  0  0  0  0  0  1  0  

0  1  0  0  0  0  0  0  

0  0  0  0  0  1  0  0  

0  0  0  0  0  0  0  1  

0  0  1  0  0  0  0  0  

0  0  0  0  1  0  0  0  

0  0  0  1  0  0  0  0 

"""